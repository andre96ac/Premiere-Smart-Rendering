
import { spawn } from "node:child_process";
import type { AppConfig, Clip, FfmpegResult } from "../types/types.js";
import { calcFinalFileName, calcFinalFilePathName, createSequenceDir, existOnFileSystem } from "./utils.js";
import { AppLog } from "./AppLog.js";


function _runFfmpeg(
  args: string[],
  ffmpegPath = "ffmpeg"
): Promise<FfmpegResult> {
  return new Promise((resolve, reject) => {
    const process = spawn(ffmpegPath, args, {
      windowsHide: true,
      stdio: ["ignore", "ignore", "pipe"],
    });

    let stderr = "";

    process.stderr.setEncoding("utf8");
    process.stderr.on("data", (chunk: string) => {
      stderr += chunk;
    });

    process.on("error", (error) => {
      reject(error);
    });

    process.on("close", (code) => {
      if (code === 0) {
        resolve({
          exitCode: 0,
          stderr,
        });
      } else {
        reject(
          new Error(
            `FFmpeg terminato con codice ${code}.\n${stderr}`
          )
        );
      }
    });
  });
}


/**
 * Esegue il taglio della clip passata e crea il nuovo file
 * @param ffmpegPath percorso eseguibile ffmpeg
 * @param baseOutputFolder cartella di base in cui inserire il video tagliato
 * @param clip elemnto clip
 * @param overwrite specifica se sovrascrivere o skippare file eventualmente presenti
 * @param separateSequences specifica se salvare i file in sottocartelle diverse per ogni sequenza
 * @returns 
 */
export async function runFfmpegSingle(ffmpegPath: string, baseOutputFolder: string, clip: Clip, overwrite: boolean = true, separateSequences: boolean): Promise<FfmpegResult>{


        if(separateSequences){
          //se siamo in modalità cartelle separate, creo prima la cartella
          await createSequenceDir(clip, baseOutputFolder);
        }

        const finalFileName = calcFinalFilePathName(baseOutputFolder, clip, separateSequences);
        const argOverwrite = overwrite? '-y' : '-n';
        const args = [
            "-hide_banner",
            argOverwrite,
            "-i", clip.filePath,
            "-ss", String(clip.startSeconds),
            "-t", String(clip.durationSeconds),
            "-map", "0:v:0",
            "-map", "0:a?",
            "-map_metadata", "0",
            "-c", "copy",
            "-avoid_negative_ts", "make_zero",
            "-movflags", "+faststart",
            finalFileName,
        ];

        const fileExist = await(existOnFileSystem(finalFileName));
        if(!fileExist){
            return _runFfmpeg(args, ffmpegPath)
        }
        else{
            if(overwrite){

                AppLog.instance.warn(`File ${finalFileName} già presente... VERRA' SOVRASCRITTO`);
                return _runFfmpeg(args, ffmpegPath)
            }
            else{

                AppLog.instance.warn(`File ${finalFileName} già presente... VERRA' SKIPPATO`);
                return {
                        exitCode: 0,
                        stderr: '',
                        };
            }
        }

}

/**
 * Processa l'intero array di clip con ffmpeg
 * @param clips 
 * @param config 
 */
export async function runFfmpeg(clips: Clip[], config: AppConfig) {
    if(! await existOnFileSystem(config.outputFolder)){
      AppLog.instance.err(`Directory di output ${config.outputFolder} Non trovata`)
      return;
    }
  
    let idx = 1;

      for (const clip of clips) {
          AppLog.instance.log(`${idx} di ${clips.length} - Taglio della clip ${calcFinalFileName(clip)}`);
          try {

              await runFfmpegSingle(
                  config.ffmpegExePath,
                  config.outputFolder,
                  clip,
                  config.overWriteFiles,
                  config.separateSequences
              );
          }
          catch (e) {
              const error: Error = e as Error;
              AppLog.instance.err(error.message, error);
          }
          idx++;
      }
}
